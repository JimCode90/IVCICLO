﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyGestionDoc_BE
{
    public class TipoGradoBE
    {
        public Int16 idTipoGrado { get; set; }
        public string descripcion { get; set; }
        public bool estado { get; set; }
    }
}
