﻿namespace ProyGestionDoc_BE
{
    public class Class1
    {

    }
}