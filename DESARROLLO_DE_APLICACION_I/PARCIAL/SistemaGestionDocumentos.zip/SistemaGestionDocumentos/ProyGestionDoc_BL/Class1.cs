﻿namespace ProyGestionDoc_BL
{
    public class Class1
    {

    }
}