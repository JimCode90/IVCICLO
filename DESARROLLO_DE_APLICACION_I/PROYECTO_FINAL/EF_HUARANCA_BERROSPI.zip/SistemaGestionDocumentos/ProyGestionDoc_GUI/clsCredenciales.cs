﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyGestionDoc_GUI
{
    public static class clsCredenciales
    {
        public static String Usuario;
        public static String Password;
        public static String NroCip;
        public static Int16 Rol;
    }
}
