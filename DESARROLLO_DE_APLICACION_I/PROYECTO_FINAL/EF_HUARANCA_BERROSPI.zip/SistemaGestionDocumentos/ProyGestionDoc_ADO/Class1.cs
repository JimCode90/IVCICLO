﻿namespace ProyGestionDoc_ADO
{
    public class Class1
    {

    }
}