﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyGestionDoc_BE
{
    public class TipoEspecieBE
    {
        public Int16 Id_tip_espec { get; set; }
        public string Opc_espec { get; set; }
        public bool Est_espec { get; set; }
    }
}
