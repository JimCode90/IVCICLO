﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyGestionDoc_BE
{
    public class UsuarioBE
    {
        public String Cip_usu { get; set; }
        public String Pass_usu { get; set; }
        public Int16 Id_Gra { get; set; }
        public String Nom_usu { get; set; }
        public String Ape_usu { get; set; }
        public String Dni_usu { get; set; }
        public String Email_usu { get; set; }
        public String Tel_usu { get; set; }
        public Int16 Rol_usu { get; set; }
        public Int16 Id_Uni { get; set; }
        public Int16 Est_usu { get; set; }
        /*public DateTime fechaRegistro { get; set; }
        public string usuRegistro { get; set; }
        */



    }
}
