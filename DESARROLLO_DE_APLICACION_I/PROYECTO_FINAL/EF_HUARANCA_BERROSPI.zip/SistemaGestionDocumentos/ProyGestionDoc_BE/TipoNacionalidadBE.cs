﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyGestionDoc_BE
{
    public class TipoNacionalidadBE
    {
        public Int16 Id_Nac { get; set; }
        public string Opc_Nac { get; set; }
        public bool Est_Nac { get; set; }
    }
}
