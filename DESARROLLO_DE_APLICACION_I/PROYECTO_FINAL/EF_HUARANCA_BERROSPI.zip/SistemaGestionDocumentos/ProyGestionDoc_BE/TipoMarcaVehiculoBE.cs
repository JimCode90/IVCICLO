﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyGestionDoc_BE
{
    public class TipoMarcaVehiculoBE
    {
        public Int16 Id_Mar_veh { get; set; }
        public string Opc_Mar_veh { get; set; }
        public bool Est_Mar_veh { get; set; }
    }
}
