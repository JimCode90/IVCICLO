﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Evaluacion01_Estructuras
{
    public partial class frmArreglos1 : Form
    {

       

        public frmArreglos1()
        {
            InitializeComponent();
        }

        private void btnGenerar_Click(object sender, EventArgs e)
        {
           // Codifique

        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            // Codifique

        }
    }
}
