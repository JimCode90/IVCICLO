package com.example.examenparcial.utils;

public class Total {
    public static String rutaServicio = "https://servicios.campus.pe/";
    //public static String rutaServicio = "https://10.0.2.2/";
    //public static String rutaServicio = "https://192.168.1.45/";
}
