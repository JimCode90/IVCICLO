package com.example.ep2restaurantes.utils;

public class Total {
    public static String rutaServicio = "https://servicioscafe2022.000webhostapp.com/";
    //public static String rutaServicio = "https://10.0.2.2/";
    //public static String rutaServicio = "https://192.168.1.45/";
}
